# AI Fitness Research & Tracking Assistant

I wanted a small app that remembers workout records and makes general fitness information easier to check against its sources. Long documents mix recommendations, measured findings and population limits. A fluent chatbot can blur those differences, so I wanted the evidence and failures to be visible.

This V1 combines a local Streamlit tracker with retrieval-augmented research. It uses pretrained models through Ollama; I did **not** train an LLM. I used AI coding and review tools to help implement and check the project. Personal history stays in an external SQLite database and is summarized by Python, not sent to the research model.

## Features and scope

- Optional profiles, daily weight/cardio/sleep check-ins, lift entries, editing, export and deletion.
- Recorded trends and lifting volume with units and missing-data caveats; explicitly synthetic demo records.
- nomic embeddings/cosine retrieval and a fixed BM25 keyword baseline.
- Local Qwen3:4b through the Ollama Python SDK, with schema-constrained JSON: status, answer, cited key points, caveats and follow-up questions.
- Mechanical checks against actual supplied citation IDs, attachment, bibliography consistency and limited unsafe/injection patterns.
- A paired evaluation on 18 frozen questions with failures retained.

This is general adult education. Diagnosis, treatment, dangerous plans, individualized medical nutrition and unsupported supplement recommendations are refused. Rules can miss paraphrases; this is not clinically validated. See [health boundaries](docs/health_boundaries.md).

## How it works

```mermaid
flowchart LR
    Q[Research question] --> S[Scope check]
    S --> P[Fixed policy response]
    S --> R[BM25 or vector retrieval]
    D[Reviewed source sections] --> C[Chunks and local embeddings]
    C --> R
    R --> L[Local LLM with supplied evidence]
    L --> V[Schema and citation checks]
    V --> U[Answer and sources]
    H[Private recorded history] --> T[Python calculations]
    T --> UI[Progress view]
```

The files under `agents/` are collaborating Python pipeline components, **not independent autonomous AI agents**. Ingestion loads/chunks sources; research delegates one bounded generation request; verification performs mechanical checks; the coordinator passes typed results between them. Development-time Codex reviewers and a separately run local Hermes review are different. Their prompts, logs and coordination notes stay outside this repository.

The corpus has 7 sources, 12 selected sections and 21 chunks: CDC activity guidance, selected NIDDK food/portion explanations, FDA label literacy and a licensed 2026 resistance-training systematic review/meta-analysis. Guidance is tagged separately from measured research. Research passages retain eligibility, population and limitations. [Data provenance and reuse](data/README.md) lists dates, omissions, licenses and extraction details. No answer-time web browsing occurs.

BM25 uses fixed k1=1.5, b=0.75 and unique lowercase alphanumeric query terms, without stemming or stopword removal. Vector retrieval normalizes document/query embeddings and ranks their dot product (cosine similarity). Both methods use the same chunks, filters, top 3 and packing policy. Similarity is relevance, not truth or confidence. Cache fingerprints include corpus metadata/order, model digest, prefixes and vector bytes.

## Evaluation and results

The 18 questions contain 8 answerable cases, 2 missing-evidence cases, 6 boundary cases and 2 controlled instruction attacks. Questions, source-derived semantic units, complete relevant-chunk labels, core-code hashes, prompt/options and model digests were frozen before paired generation. Gold rubrics never enter the generation prompt. Method order alternates; each pair gets one attempt with no hidden retry.

Automatic metrics cover hit@3, chunk recall@3, evidence-unit coverage, schema validity, citation identity and a key-point attachment proxy. Zero citations or an empty gold set is N/A, not perfect. Policy responses are separate from answerable retrieval metrics. Timing is total request time with mixed model-loading conditions, not controlled warm/cold or separate-stage timing.

Semantic review checks required meanings and atomic claims against **actual supplied evidence**, including narrative/caveats. Citation attachment and entailment differ from identity checks. Judgments are AI-assisted, blinded to retrieval method during initial review, with evidence rationales and root adjudication. They are not independent human or clinical validation. This small related set does not establish a statistically reliable winner.

The completed run had 36 attempted outputs and no transport/schema failures. Both retrievers reached 100% evidence-unit coverage on eight answerable cases, but the model marked every generated response as insufficient evidence. Mean completeness was 47.9% for BM25 and 55.2% for vectors; reviewed unsupported-claim rates were 25.8% and 28.7%. These are small-set, AI-assisted measurements, not validated accuracy claims. The retrieval worked better than the answer behavior, so this V1 is an experimental prototype with visible failures. See [evaluation report](reports/evaluation_summary.md), [per-question CSV](reports/evaluation_results.csv) and [answer/evidence audit](reports/answer_audit.json).

## Run locally (PowerShell)

Prerequisites: Python 3.12, `uv` or pip, and running Ollama. Docker and Hermes are **not required**. No application API key is needed. Model downloads require network/disk space; application generation is local.

```powershell
Set-Location <your-project-folder>
uv venv --python 3.12 .venv
uv pip install --python .\.venv\Scripts\python.exe -r requirements.txt
ollama pull qwen3:4b
ollama pull nomic-embed-text:v1.5
.\.venv\Scripts\python.exe scripts\build_index.py
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
```

Open http://127.0.0.1:8501. Demo mode uses synthetic records. Turn it off for an empty private store. Saving a daily check-in replaces that date's entire record; omitted values become unknown. Body mass/load are stored in kg and height in cm. Missing days are not zero. Logged load×sets×reps is volume, not proof of increased strength.

Settings use environment variables; `.env.example` documents them but is **not automatically loaded**. Defaults use loopback Ollama and an external sibling `<project-folder>-private` for databases, vectors and raw evaluation traces. An optional override must remain outside the project:

```powershell
$env:FITNESS_PRIVATE_DIR = 'C:\path\outside-project\fitness-private'
$env:OLLAMA_MODEL = 'qwen3:4b'
```

The app is single-owner local software, without authentication or database encryption. Do not expose it publicly with real records. Ignore rules are a second protection; the default storage path already lies outside the repo.

## Tests and reproduction

```powershell
.\.venv\Scripts\python.exe -m pytest -q -p no:cacheprovider
.\.venv\Scripts\python.exe scripts\run_evaluation.py --run-id my-new-run
```

Tests cover sources/chunk metadata, BM25/cosine ranking, cache freshness, SQLite persistence/isolation, units/missingness, schemas, boundaries, citations, failure retention, exact metric denominators and Streamlit flows. Tests use controlled fakes; the recorded benchmark uses actual local models.

The evaluator rejects changed frozen files/model digests and refuses to overwrite a run ID. Results stay private unless `--publish` is explicitly supplied. That flag writes parsed reports; it does not perform semantic review or select the best run. `scripts/finalize_evaluation.py` merges explicit unit/claim decisions with completeness checks, without keyword scoring. Initial automatic outputs remain privately retained. A rerun does not inherit published semantic judgments.

If a sandbox cannot access pytest's Windows temp folder, use a newly named external private directory with `--basetemp` and `-p no:cacheprovider`. Never use a personal-record directory as pytest temp storage. Dependencies are pinned; model digests are recorded. Temperature 0 does not guarantee identical outputs.

## Limitations and future work

The corpus is small and dated. NIDDK's 2020/2021 review dates are retained; only selected educational concepts are used. It does not cover all fitness/nutrition research, personal optimal programming or supplement efficacy. Mechanical checks and schema constraints cannot guarantee factuality or medical safety.

The local model can over-abstain or make unsupported assertions; the report shows the measured extent. Saving history does not train the model. Profiles do not generate personal programs in V1. Human claim review, fresh held-out questions, broader research, safe tracking follow-ups, date-range summaries, food/wearable imports and controlled model/prompt experiments are future work. Docker containerization and hosted accounts were not built or validated.

## Files

```text
app.py       Streamlit demo
agents/      Typed pipeline orchestration components
src/         Sources, retrieval, SDK, storage, calculations, metrics
data/        Reviewed snapshots and synthetic history
eval/        Frozen questions, rubrics and manifest
scripts/     Source refresh, indexing, evaluation and review merge
reports/     Measured results and evidence audit
tests/       Automated behavior and calculation checks
docs/        Public health-scope contract
```
