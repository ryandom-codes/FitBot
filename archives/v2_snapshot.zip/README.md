# AI Fitness Research & Tracking Assistant

I wanted a small app that remembers workout records and makes general fitness information easier to check against its sources. Long documents mix recommendations, measured findings and population limits. A fluent chatbot can blur those differences, so I wanted the evidence and failures to be visible.

This V1 combines a local Streamlit tracker with retrieval-augmented research. It uses pretrained models through Ollama; I did **not** train an LLM. I used AI coding and review tools to help implement and check the project. Personal history stays in an external SQLite database and is summarized by Python, not sent to the research model.

## Features and scope

- Optional profiles, daily weight/cardio/sleep check-ins, lift entries, editing, export and deletion.
- Recorded trends and lifting volume with units and missing-data caveats; explicitly synthetic demo records.
- nomic embeddings/cosine retrieval and a fixed BM25 keyword baseline.
- Local Qwen3.5:4b-q4_K_M through the Ollama Python SDK, with schema-constrained JSON: status, answer, cited key points, caveats and follow-up questions.
- Mechanical checks against actual supplied citation IDs, attachment, bibliography consistency and limited unsafe/injection patterns.
- A paired evaluation on 18 frozen questions with failures retained.

This is general adult education. Diagnosis, treatment, dangerous plans, individualized medical nutrition and unsupported supplement recommendations are refused. Rules can miss paraphrases; this is not clinically validated. See [health boundaries](docs/health_boundaries.md).

## How it works

```mermaid
flowchart LR
    Q[Research question] --> S[Scope check]
    S --> P[Fixed policy response]
    S --> R[BM25 or vector retrieval]
    D[Reviewed source sections] --> C[Chunks and local embeddings]
    C --> R
    R --> L[Local LLM with supplied evidence]
    L --> V[Schema and citation checks]
    V --> U[Answer and sources]
    H[Private recorded history] --> T[Python calculations]
    T --> UI[Progress view]
```

The files under `agents/` are collaborating Python pipeline components, **not independent autonomous AI agents**. Ingestion loads/chunks sources; research delegates one bounded generation request; verification performs mechanical checks; the coordinator passes typed results between them. Development-time Codex reviewers and a separately run local Hermes review are different. Their prompts, logs and coordination notes stay outside this repository.

The corpus has 7 sources, 12 selected sections and 21 chunks: CDC activity guidance, selected NIDDK food/portion explanations, FDA label literacy and a licensed 2026 resistance-training systematic review/meta-analysis. Guidance is tagged separately from measured research. Research passages retain eligibility, population and limitations. [Data provenance and reuse](data/README.md) lists dates, omissions, licenses and extraction details. No answer-time web browsing occurs.

BM25 uses fixed k1=1.5, b=0.75 and unique lowercase alphanumeric query terms, without stemming or stopword removal. Vector retrieval normalizes document/query embeddings and ranks their dot product (cosine similarity). Both methods use the same chunks, filters, top 3 and packing policy. Similarity is relevance, not truth or confidence. Cache fingerprints include corpus metadata/order, model digest, prefixes and vector bytes.

## Evaluation and results

The current paired V2 evaluation uses 18 frozen questions: 10 answerable, 2 missing-evidence, 4 health-boundary and 2 prompt-injection cases. It ran 36 attempts locally, with the same evidence and retrieval limits for BM25 and vector search. The test set, code and local model identities were frozen before generation.

On these ten answerable questions, BM25 reached 90% hit@3, 85% chunk recall and 90% labeled evidence-unit coverage. Vector search reached 100% on all three. AI-assisted review found mean question-level completeness of 76.7% for BM25 and 91.7% for vector search; pooled required-fact coverage was 18/27 and 25/27. Eight of ten vector answers and six of ten keyword answers fulfilled every required fact. The review also found a keyword response that cited a correct sleep-duration table when asked for sleep habits, showing why quote validity alone is not enough.

All citation IDs and checked source quotes were mechanically valid. The AI-assisted review identified no unsupported claims relative to the supplied passages, but this is AI-assisted evidence review, not human or clinical validation. Both methods matched expected answer status on this small set. The safety router handled four boundary questions without generation; both methods abstained on two missing-evidence questions and resisted two prompt-injection notes. Both answers to the intensity-and-talk-test injection question still missed its requested numeric effort-scale detail. A frozen N10 rubric item combines two requirements with an OR-style evidence bundle, so its evidence-unit coverage may be optimistic.

These results favor vector retrieval on this particular small test set, but they do not establish a general winner. Response-time mean, median and p95, denominators, limitations and next improvements are in the [evaluation report](reports/evaluation_summary.md). The earlier model run is preserved in [the V1 report](reports/v1/evaluation_summary.md).

## Run locally (PowerShell)

Prerequisites: Python 3.12, `uv` or pip, and running Ollama. Docker and Hermes are **not required**. No application API key is needed. Model downloads require network/disk space; application generation is local.

```powershell
Set-Location <your-project-folder>
uv venv --python 3.12 .venv
uv pip install --python .\.venv\Scripts\python.exe -r requirements.txt
ollama pull qwen3.5:4b-q4_K_M
ollama pull nomic-embed-text:v1.5
.\.venv\Scripts\python.exe scripts\build_index.py
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
```

Open http://127.0.0.1:8501. Demo mode uses synthetic records. Turn it off for an empty private store. Saving a daily check-in replaces that date's entire record; omitted values become unknown. Body mass/load are stored in kg and height in cm. Missing days are not zero. Logged load×sets×reps is volume, not proof of increased strength.

Settings use environment variables; `.env.example` documents them but is **not automatically loaded**. Defaults use loopback Ollama and an external sibling `<project-folder>-private` for databases, vectors and raw evaluation traces. An optional override must remain outside the project:

```powershell
$env:FITNESS_PRIVATE_DIR = 'C:\path\outside-project\fitness-private'
$env:OLLAMA_MODEL = 'qwen3.5:4b-q4_K_M'
```

The app is single-owner local software, without authentication or database encryption. Do not expose it publicly with real records. Ignore rules are a second protection; the default storage path already lies outside the repo.

## Tests and reproduction

```powershell
.\.venv\Scripts\python.exe -m pytest -q -p no:cacheprovider
.\.venv\Scripts\python.exe scripts\run_evaluation.py --run-id my-new-run
```

Tests cover sources/chunk metadata, BM25/cosine ranking, cache freshness, SQLite persistence/isolation, units/missingness, schemas, boundaries, citations, failure retention, exact metric denominators and Streamlit flows. Tests use controlled fakes; the recorded benchmark uses actual local models.

The evaluator rejects changed frozen files/model digests and refuses to overwrite a run ID. Results stay private unless `--publish` is explicitly supplied. That flag writes parsed reports; it does not perform semantic review or select the best run. `scripts/finalize_evaluation.py` merges explicit unit/claim decisions with completeness checks, without keyword scoring. Initial automatic outputs remain privately retained. A rerun does not inherit published semantic judgments.

If a sandbox cannot access pytest's Windows temp folder, use a newly named external private directory with `--basetemp` and `-p no:cacheprovider`. Never use a personal-record directory as pytest temp storage. Dependencies are pinned; model digests are recorded. Temperature 0 does not guarantee identical outputs.

## Limitations and future work

The corpus is small and dated. NIDDK's 2020/2021 review dates are retained; only selected educational concepts are used. It does not cover all fitness/nutrition research, personal optimal programming or supplement efficacy. Mechanical checks and schema constraints cannot guarantee factuality or medical safety.

The local model can over-abstain or make unsupported assertions; the report shows the measured extent. Saving history does not train the model. Profiles do not generate personal programs in V1. Human claim review, fresh held-out questions, broader research, safe tracking follow-ups, date-range summaries, food/wearable imports and controlled model/prompt experiments are future work. Docker containerization and hosted accounts were not built or validated.

## Files

```text
app.py       Streamlit demo
agents/      Typed pipeline orchestration components
src/         Sources, retrieval, SDK, storage, calculations, metrics
data/        Reviewed snapshots and synthetic history
eval/        Frozen questions, rubrics and manifest
scripts/     Source refresh, indexing, evaluation and review merge
reports/     Measured results and evidence audit
tests/       Automated behavior and calculation checks
docs/        Public health-scope contract
```
