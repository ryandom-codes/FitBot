# Preserved V1

`v1_snapshot.zip` contains the exact 52-file reviewed public candidate before V2 changes, including original code, sources, questions, dependency pins and all measured reports. No virtual environment, Git metadata, private notes or real records is included. Individual SHA256 hashes are recorded in v1_file_manifest.json; ZIP SHA256: `4d4886065896ca12e3342ed4041af2b456c4d2a20469ccdb6264fb1d24261d67`.

V1 failures remain part of the project history. A readable copy of the original result files is in reports/v1. Relative links inside that unchanged historical report refer to its original root layout; use the ZIP layout when following those links. No old result was recalculated using V2 code.

To reproduce original code, extract the ZIP into a new folder, read its README, create a separate virtual environment/private storage, and run with the recorded model digests. Temperature zero is not a guarantee of identical generations. The archived app is an experimental local prototype, not validated medical software.
